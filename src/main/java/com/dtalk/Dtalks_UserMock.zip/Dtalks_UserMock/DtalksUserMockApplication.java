package com.dtalk.Dtalks_UserMock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtalksUserMockApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtalksUserMockApplication.class, args);
	}

}
