package com.dtalk.Dtalks_UserMock.dto;

public class UserRequest {
}
