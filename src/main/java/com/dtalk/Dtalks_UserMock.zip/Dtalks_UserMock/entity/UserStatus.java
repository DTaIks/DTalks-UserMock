package com.dtalk.Dtalks_UserMock.entity;

public enum UserStatus {
    activated, deactivated, inoperative
}

